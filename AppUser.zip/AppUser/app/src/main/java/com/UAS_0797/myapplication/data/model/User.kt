package com.UAS_0797.myapplication.data.model

data class User(
    val login: String,
    val avatar_url: String
)