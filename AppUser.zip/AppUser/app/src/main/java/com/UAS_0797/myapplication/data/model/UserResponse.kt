package com.UAS_0797.myapplication.data.model

data class UserResponse(
    val items : ArrayList<User>
)